﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);


            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n"
                + "Matricula=" + objMensalista.Matricula + "\n" +
                "Tempo Trabalho:" + objMensalista.TempoTrabalho() +
                "\n" + "Salario Final=" +
                objMensalista.SalarioBruto().ToString("N2"));

            MessageBox.Show("Empresa: " + Mensalista.Empresa);
        }

        private void frmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Nome=" + objMensalista.NomeEmpregado + "\n"
               + "Matricula=" + objMensalista.Matricula + "\n" +
               "Tempo Trabalho:" + objMensalista.TempoTrabalho() +
               "\n" + "Salario Final=" +
               objMensalista.SalarioBruto().ToString("N2"));
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
